using System.IO;
using System;


class Program {
  public static void Main (string[] arg) 
  {
    int chislo = Convert.ToInt32(Console.ReadLine()); Console.WriteLine (chislo);
    int[] matrix = new int[chislo]; Random synt = new Random();
    for (int i = 0; i < chislo; i++){
      matrix[i] = synt.Next();}
    Console.WriteLine("[{0}]", string.Join(", ", matrix));
    Array.Sort(matrix);//сортировка
    string str = string.Join(" ", matrix);
    string name = Console.ReadLine(); Console.WriteLine (name);
    name = name.Insert(name.Length, " ");
    name = name.Insert(name.Length, str);
    string path = "programresult.txt"; File.WriteAllText(path, name);}
  }
  
